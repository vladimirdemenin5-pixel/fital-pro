ALTER TABLE subscriptions ADD COLUMN expires_at TEXT;
CREATE INDEX IF NOT EXISTS idx_subscriptions_expiry ON subscriptions(expires_at);
