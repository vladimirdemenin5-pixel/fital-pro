const menuBtn = document.querySelector('.menu-btn');
const nav = document.querySelector('.nav');

menuBtn?.addEventListener('click', () => {
  nav.classList.toggle('open');
  menuBtn.setAttribute('aria-expanded', nav.classList.contains('open'));
});
nav?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));

// Smooth scrolling with a small mobile header offset.
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

// Plan selection persists while the user moves around the page.
const planField = document.getElementById('planField');
const savedPlan = localStorage.getItem('fitalpro_plan');
if (planField && savedPlan) planField.value = savedPlan;
document.querySelectorAll('[data-plan]').forEach(a => a.addEventListener('click', () => {
  const plan = a.dataset.plan || '';
  if (planField) planField.value = plan;
  localStorage.setItem('fitalpro_plan', plan);
}));

// Fital AI: production API with a local fallback only when the server is unavailable.
// the site automatically tries it first and falls back to the local answers.
const log = document.getElementById('chatLog');
const input = document.getElementById('chatInput');
const answers = [
  ['куриц', 'Курицу можно заменить индейкой, нежирной рыбой, яйцами, творогом или растительным источником белка. В полноценной программе порцию лучше считать по калорийности и белку вашего плана.'],
  ['рыб', 'Если рыба вам не подходит, варианты белка зависят от меню: птица, яйца, кисломолочные продукты или бобовые. Подбирайте замену с близким количеством белка и учитывайте калорийность.'],
  ['пропуст', 'Не нужно компенсировать пропуск двойной тренировкой. Вернитесь к следующей запланированной тренировке, а если вы устали или плохо восстановились — снизьте нагрузку.'],
  ['вод', 'Удобно распределять воду равномерно в течение дня. Потребность зависит от активности, температуры и индивидуальных особенностей; при медицинских ограничениях ориентируйтесь на рекомендации врача.'],
  ['калори', 'Калорийность должна зависеть от цели, возраста, пола, роста, веса и активности. В Fital Pro этот расчёт предполагается делать после анкеты, а не по одному универсальному числу.'],
  ['трениров', 'Для прогресса важнее регулярность и восстановление, чем максимальная нагрузка. Начинайте с уровня, который можете выполнять стабильно, и постепенно увеличивайте объём.'],
  ['завтра', 'Хороший базовый вариант: источник белка + сложные углеводы + овощи/фрукты. Конкретный завтрак лучше выбирать из вашего плана и предпочтений.']
];
function addMsg(text, cls) {
  if (!log) return;
  const d = document.createElement('div');
  d.className = `msg ${cls}`;
  d.textContent = text;
  log.appendChild(d);
  log.scrollTop = log.scrollHeight;
}
function localReply(q) {
  const low = q.toLowerCase();
  const hit = answers.find(([k]) => low.includes(k));
  return hit ? hit[1] : 'В полной версии Fital AI ответ будет учитывать вашу анкету и персональную программу. Сейчас сайт работает в демонстрационном режиме.';
}
async function reply(q) {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const r = await fetch('/api/chat', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: q }), headers: { 'Content-Type':'application/json', ...(localStorage.getItem('fitalpro_access_token') ? {Authorization:'Bearer '+localStorage.getItem('fitalpro_access_token')} : {}) }, signal: controller.signal
    });
    clearTimeout(timer);
    if (r.ok) {
      const data = await r.json();
      if (data.reply) return addMsg(data.reply, 'bot');
    }
  } catch (_) {}
  setTimeout(() => addMsg(localReply(q), 'bot'), 250);
}

document.querySelectorAll('.chips button').forEach(b => b.addEventListener('click', () => {
  const q = b.dataset.q || '';
  addMsg(q, 'user'); reply(q);
}));
document.getElementById('chatForm')?.addEventListener('submit', e => {
  e.preventDefault();
  const q = input.value.trim();
  if (!q) return;
  addMsg(q, 'user'); input.value = ''; reply(q);
});

// Lead form: saves a draft locally immediately and attempts the future API endpoint.
const leadForm = document.getElementById('leadForm');
const formNote = document.getElementById('formNote');
leadForm?.addEventListener('submit', async e => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(leadForm).entries());
  localStorage.setItem('fitalpro_lead_draft', JSON.stringify({ ...data, savedAt: new Date().toISOString() }));
  if (data.contact) localStorage.setItem('fitalpro_contact', data.contact);
  const button = leadForm.querySelector('button[type="submit"]');
  if (button) { button.disabled = true; button.textContent = 'Отправляем…'; }
  let sent = false;
  try {
    const r = await fetch('/api/lead', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
    sent = r.ok;
  } catch (_) {}
  if (sent) {
    formNote.textContent = 'Заявка отправлена. Мы свяжемся с вами для уточнения деталей.';
    leadForm.reset();
    if (planField) planField.value = localStorage.getItem('fitalpro_plan') || '';
  } else {
    formNote.textContent = 'Заявка сохранена на этом устройстве. После подключения сервера она будет автоматически отправляться владельцу сайта.';
  }
  if (button) { button.disabled = false; button.textContent = 'Отправить заявку'; }
});

// Small accessibility improvement: reveal page after assets are ready.
document.documentElement.classList.add('js');

// Real checkout: creates a secure server-side payment and redirects to the provider.
document.querySelectorAll('[data-checkout]').forEach(btn => btn.addEventListener('click', async () => {
  const plan = btn.dataset.checkout;
  const original = btn.textContent;
  btn.disabled = true; btn.textContent = 'Создаём оплату…';
  try {
    const r = await fetch('/api/checkout', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ plan, contact: localStorage.getItem('fitalpro_contact') || '', client_ref: crypto.randomUUID() })
    });
    const data = await r.json();
    if (!r.ok || !data.confirmation_url) throw new Error(data.error || 'Не удалось создать оплату');
    window.location.href = data.confirmation_url;
  } catch (e) {
    alert(e.message || 'Оплата пока недоступна.');
    btn.disabled = false; btn.textContent = original;
  }
}));


// Payment return page: poll server until the webhook confirms the payment.
(async function handlePaymentReturn(){
  const params=new URLSearchParams(location.search);
  const payment=params.get('payment_id');
  const paymentRef=params.get('payment_ref');
  const result=document.getElementById('paymentResult');
  if ((!payment && !paymentRef) || !result) return;
  result.hidden=false;
  const title=document.getElementById('paymentTitle');
  const text=document.getElementById('paymentText');
  const access=document.getElementById('paymentAccess');
  for(let i=0;i<8;i++){
    try{
      const query=payment ? 'id='+encodeURIComponent(payment) : 'ref='+encodeURIComponent(paymentRef);
      const r=await fetch('/api/payment-status?'+query,{cache:'no-store'});
      const d=await r.json();
      if(d.status==='active' || d.status==='succeeded'){
        title.textContent='Оплата подтверждена ✓';
        if(d.access_token) localStorage.setItem('fitalpro_access_token', d.access_token);
        text.textContent='Ваш тариф активирован. Доступ сохранён на этом устройстве.';
        access.hidden=false;
        result.scrollIntoView({behavior:'smooth'});
        return;
      }
      title.textContent='Платёж обрабатывается';
      text.textContent='Платёж принят. Ждём подтверждение платёжной системы…';
    }catch(e){}
    await new Promise(r=>setTimeout(r,2500));
  }
  title.textContent='Проверка ещё выполняется';
  text.textContent='Если деньги уже списаны, обновите страницу через минуту.';
})();


// Member access: if a token exists in the URL or storage, show current subscription status.
(function memberAccess(){
  const params=new URLSearchParams(location.search);
  const token=params.get('access_token') || localStorage.getItem('fitalpro_access_token');
  if (params.get('access_token')) localStorage.setItem('fitalpro_access_token', params.get('access_token'));
  const panel=document.getElementById('memberPanel');
  if (!token || !panel) return;
  fetch('/api/me',{headers:{Authorization:'Bearer '+token},cache:'no-store'}).then(r=>r.ok?r.json():Promise.reject()).then(d=>{
    panel.hidden=false;
    const plan=panel.querySelector('[data-member-plan]');
    const status=panel.querySelector('[data-member-status]');
    if(plan) plan.textContent=d.subscription?.plan || '—';
    if(status) status.textContent=d.subscription?.status==='active' ? 'Активна' : 'Статус: '+(d.subscription?.status || 'неизвестен');
  }).catch(()=>{ localStorage.removeItem('fitalpro_access_token'); });
})();


// Personal profile and plan. Server persistence is available for active subscribers;
// the same profile is also kept locally so the form survives page reloads.
(function profileModule(){
  const form=document.getElementById('profileForm');
  const note=document.getElementById('profileNote');
  const card=document.getElementById('planCard');
  if(!form) return;
  const token=()=>localStorage.getItem('fitalpro_access_token')||'';
  const localKey='fitalpro_profile';
  try{
    const saved=JSON.parse(localStorage.getItem(localKey)||'null');
    if(saved) Object.entries(saved).forEach(([k,v])=>{const el=form.elements[k]; if(el) el.value=v});
  }catch(_){ }
  const render=(d)=>{
    if(!d?.plan||!card) return;
    card.hidden=false;
    document.getElementById('planCalories').textContent=d.plan.calories+' ккал';
    document.getElementById('planProtein').textContent=d.plan.protein+' г';
    document.getElementById('planDays').textContent=d.plan.days+'× / нед.';
    const list=document.getElementById('planList'); list.innerHTML='';
    const summary=[`Цель: ${d.plan.goal||'—'}`,`Средняя дневная норма: ${d.plan.averageDaily?.kcal||d.plan.calories} ккал`,`Средний белок: ${d.plan.averageDaily?.protein||d.plan.protein} г`]; summary.forEach(x=>{const li=document.createElement('li');li.textContent=x;list.appendChild(li)});
    const week=document.getElementById('weekPlan');
    if(week && d.plan.week){
      week.innerHTML='<h4>План на 7 дней</h4>'+d.plan.week.map(x=>`<article class=\"day-plan\"><b>День ${x.day}</b><span>${x.training}</span><p>${Object.values(x.meals).map(m=>m.name||m).join(' • ')}</p></article>`).join('');
    }
    window.dispatchEvent(new CustomEvent('fital:plan-updated',{detail:d.plan}));
  };
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    const data=Object.fromEntries(new FormData(form).entries());
    localStorage.setItem(localKey,JSON.stringify(data));
    note.textContent='Сохраняем профиль…';
    if(!token()){
      note.textContent='Профиль сохранён на устройстве. После активации подписки он будет синхронизирован с сервисом.';
      return;
    }
    try{
      const r=await fetch('/api/profile',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token()},body:JSON.stringify(data)});
      const d=await r.json();
      if(!r.ok) throw new Error(d.error||'Не удалось сохранить профиль');
      render(d); note.textContent='Профиль сохранён. Персональный план обновлён.';
    }catch(err){note.textContent=err.message||'Не удалось сохранить профиль.'}
  });
  async function load(){
    if(!token()) return;
    try{
      const r=await fetch('/api/profile',{headers:{Authorization:'Bearer '+token()},cache:'no-store'});
      if(r.ok){const d=await r.json(); if(d.profile){Object.entries(d.profile).forEach(([k,v])=>{const el=form.elements[k];if(el)el.value=v});}}
      const pr=await fetch('/api/plan',{headers:{Authorization:'Bearer '+token()},cache:'no-store'});
      if(pr.ok) render(await pr.json());
    }catch(_){ }
  }
  load();
})();


// Fital Pro dashboard: recipes, shopping list, substitutions and progress.
(function dashboardModule(){
  const recipeBox=document.getElementById('recipeList'), shopBox=document.getElementById('shoppingList'), subBox=document.getElementById('subList');
  const pf=document.getElementById('progressForm'), pn=document.getElementById('progressNote'), hist=document.getElementById('progressHistory');
  const token=()=>localStorage.getItem('fitalpro_access_token')||'';
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  function renderPlan(plan){
    if(!plan) return;
    if(recipeBox){ recipeBox.innerHTML=plan.week.flatMap(d=>d.meals.map(m=>`<article class="recipe-item"><div><b>День ${d.day} · ${esc(m.type)}</b><span>${esc(m.name)}</span><small>${m.kcal} ккал · ${m.protein} г белка</small><small>${m.ingredients.map(x=>esc(x[0])+': '+esc(x[1])).join(' · ')}</small></div></article>`)).join(''); }
    if(shopBox){ shopBox.innerHTML=plan.shopping.map(x=>`<label class="shop-row"><input type="checkbox"> <span>${esc(x.item)}</span><small>${esc(x.amount)}</small></label>`).join(''); }
    if(subBox){ const keys=Object.keys(plan.substitutions||{}); subBox.innerHTML=keys.slice(0,12).map(k=>`<div class="sub-row"><b>${esc(k)}</b><span>${plan.substitutions[k].map(esc).join(' · ')}</span></div>`).join(''); }
  }
  async function loadPlan(){ if(!token()) return; try{const r=await fetch('/api/plan',{headers:{Authorization:'Bearer '+token()},cache:'no-store'}); if(r.ok){const d=await r.json();renderPlan(d.plan)}}catch(_){} }
  async function loadProgress(){ if(!token()||!hist)return; try{const r=await fetch('/api/progress',{headers:{Authorization:'Bearer '+token()},cache:'no-store'});if(!r.ok)return;const d=await r.json();hist.innerHTML=(d.items||[]).slice(0,10).map(x=>`<div class="progress-row"><b>${esc(x.date)}</b><span>${x.weight} кг</span><small>${x.completed_workout?'✓ тренировка':''} ${x.completed_meal?'✓ питание':''}</small></div>`).join('')||'<p class="muted">Пока нет записей.</p>'}catch(_){} }
  pf?.addEventListener('submit',async e=>{e.preventDefault();if(!token()){pn.textContent='Для сохранения прогресса нужна активная подписка.';return;}const f=new FormData(pf);const data=Object.fromEntries(f.entries());data.completed_workout=pf.elements.completed_workout.checked?1:0;data.completed_meal=pf.elements.completed_meal.checked?1:0;pn.textContent='Сохраняем…';try{const r=await fetch('/api/progress',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token()},body:JSON.stringify(data)});const d=await r.json();if(!r.ok)throw new Error(d.error||'Ошибка');pn.textContent=d.trend===0?'Прогресс сохранён.':'Прогресс сохранён. Изменение веса: '+d.trend+' кг.';loadProgress()}catch(err){pn.textContent=err.message}});
  loadPlan(); loadProgress();
  window.addEventListener('fital:plan-updated',e=>renderPlan(e.detail));
})();
